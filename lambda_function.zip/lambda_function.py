import boto3

def start_stop_instances(event, context):
    ec2 = boto3.client('ec2')
    schedule = event['time']
    if schedule == "start":
        ec2.start_instances(InstanceIds=event['instance_ids'])
    elif schedule == "stop":
        ec2.stop_instances(InstanceIds=event['instance_ids'])

